package minion.kim.wannab;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class AddItemFragment extends Fragment {

    String url_get = "http://meeneeon.ddns.net/android_db_api/read_all.php?id=";
    String url_add = "http://meeneeon.ddns.net/android_db_api/add_cart.php?id=";

    ArrayList<CardItem> Item_List;
    ArrayList<itemtype>imglnk_list;

    private AlertDialog mDialog = null;

    public static final String NAME = "name";
    public static final String PRICE = "price";
    public static final String WHO = "who";
    public static final String WHERE = "where";
    public static final String IMGLNK = "imglnk";

    RecyclerView mRecyclerView;
    RecyclerView.LayoutManager mLayoutManager;
    RecyclerView.Adapter mAdapter;

    int totalitems = 0;

    int Drama_name;
    String dname;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){

        Drama_name = AppController.getInstance().getSelectedDrama();



        if(Drama_name == 0){
            dname = "프로듀사";
        }
        else if(Drama_name == 1){
            dname = "별에서온%20그대";
        }
        else if(Drama_name == 2){
            dname = "그녀는%20예뻤다";
        }

        Log.d("drama name: ", dname);

        ReadFromDB();

        View rootView = inflater.inflate(R.layout.fragment_additem, container, false);

        getActivity().setTitle("잇 아이템");

        Item_List = new ArrayList<CardItem>();
        imglnk_list = new ArrayList<itemtype>();

        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view_items);
        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);

        ItemClickSupport.addTo(mRecyclerView).setOnItemClickListener(new ItemClickSupport.OnItemClickListener() {
            @Override
            public void onItemClicked(RecyclerView recyclerView, int position, View v) {
                AppController.getInstance().setIdxDelete(position);

                mDialog = createInflaterDialog();
                mDialog.show();
            }
        });

        updateAdapter();

        return rootView;
    }

    public class itemtype{
        public String _imglnk;
    }

    private AlertDialog createInflaterDialog() {
        final View innerView = getActivity().getLayoutInflater().inflate(R.layout.dialog_add, null);
        AlertDialog.Builder ab = new AlertDialog.Builder(getActivity());
        ab.setTitle("항목 추가");
        ab.setView(innerView);

        ab.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                setAdd(mDialog);
            }
        });

        ab.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                setDismiss(mDialog);
            }
        });

        return ab.create();
    }

    private void setAdd(Dialog dialog){
        if(dialog != null && dialog.isShowing()) {
            addDB(AppController.getInstance().getIdxDelete());
            dialog.dismiss();
        }
    }

    private void setDismiss(Dialog dialog){
        if(dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }

    private void updateAdapter()
    {
        mAdapter = new CardAdapter(Item_List, getActivity());
        mRecyclerView.setAdapter(mAdapter);
    }

    private void addDB(int idx)
    {
        String add_url = url_add + '"' + Item_List.get(idx).getLink() + '"';
        Log.d("wannabe addurl : ", add_url);
        JsonObjectRequest delete_request = new JsonObjectRequest(add_url,
                null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {

                try {
                    int success = response.getInt("success");

                    if (success == 1) {
                        ReadFromDB();
                        Toast.makeText(getActivity(),
                                "장바구니에 추가되었습니다.",
                                Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(getActivity(),
                                "장바구니에서 추가하는것을 실패하였습니다", Toast.LENGTH_SHORT)
                                .show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(delete_request);
    }

    private void ReadFromDB()
    {
        AppController.getInstance().setTotalValue(0);

        Log.d("wannabe : ", url_get + dname);
        String geturl = url_get + dname;
        JsonObjectRequest req = new JsonObjectRequest(geturl, null,
                new Response.Listener<JSONObject>(){

                    @Override
                    public void onResponse(JSONObject response){
                        try{
                            Log.d("dd", "ddddd");
                            int success = response.getInt("success");
                            Log.d("issuccess",String.valueOf(success));

                            if(success == 1){
                                JSONArray ja = response.getJSONArray("items");
                                totalitems = ja.length();

                                for (int i = 0; i < ja.length(); i++){
                                    JSONObject obj = ja.getJSONObject(i);
                                    CardItem item = new CardItem();

                                    item.setName(obj.getString(NAME));
                                    item.setPrice(obj.getString(PRICE));
                                    item.setWhere(obj.getString(WHERE));
                                    item.setWho(obj.getString(WHO));
                                    item.setLink(obj.getString(IMGLNK));

                                    Log.d("itemname : ", item.getName());

                                    Item_List.add(item);

                                    Log.d("wannabe : ", "updateadaptor");
                                    updateAdapter();

                                }
                            }
                        } catch(JSONException e){
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError err){
                Log.d("wannabe : ", "volleyerror");
            }
        });

        AppController.getInstance().addToRequestQueue(req);
    }
}
