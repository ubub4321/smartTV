package minion.kim.wannab;

import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.ClipData;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import android.app.ProgressDialog;
import android.widget.TextView;
import android.widget.Toast;


public class HomeFragment extends Fragment {

    ArrayList<CardItem_SelectDrama> Item_List;

    RecyclerView mRecyclerView;
    RecyclerView.LayoutManager mLayoutManager;
    RecyclerView.Adapter mAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        getActivity().setTitle("드라마 선택");

        Item_List = new ArrayList<CardItem_SelectDrama>();

        // drama list 등록
        CardItem_SelectDrama item = new CardItem_SelectDrama();
        CardItem_SelectDrama item1 = new CardItem_SelectDrama();
        CardItem_SelectDrama item2 = new CardItem_SelectDrama();

        item.setDbname("프로듀사");
        item.setKey(0);
        item.setName("프로듀사");
        Item_List.add(item);
        item1.setDbname("별에서온 그대");
        item1.setKey(1);
        item1.setName("별에서 온 그대");
        Item_List.add(item1);
        item2.setDbname("그녀는 예뻤다");
        item2.setKey(2);
        item2.setName("그녀는 예뻤다");

        Item_List.add(item2);

        //


        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view_home);
        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);

        mAdapter = new CardAdapter_SelectDrama(Item_List, getActivity());
        mRecyclerView.setAdapter(mAdapter);

        ItemClickSupport.addTo(mRecyclerView).setOnItemClickListener(new ItemClickSupport.OnItemClickListener() {
            @Override
            public void onItemClicked(RecyclerView recyclerView, int position, View v) {
                AppController.getInstance().setIdxDelete(position);
                AppController.getInstance().setSelectedDrama(Item_List.get(position).getKey());

                Fragment fr = null;
                FragmentManager fm = getFragmentManager();

                fr = new AddItemFragment();
                fm.beginTransaction()
                        .replace(R.id.container, fr)
                        .commit();
            }
        });

        return rootView;
    }






}


