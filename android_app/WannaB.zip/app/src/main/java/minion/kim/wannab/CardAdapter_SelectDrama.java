package minion.kim.wannab;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class CardAdapter_SelectDrama extends RecyclerView.Adapter<CardAdapter_SelectDrama.ViewHolder> {

    List<CardItem_SelectDrama> mItems;
    public Context cxt;

    public CardAdapter_SelectDrama(ArrayList Items, Context _cxt) {
        super();
        this.cxt = _cxt;
        mItems = Items;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.recycler_view_card_item_select, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        CardItem_SelectDrama item = mItems.get(i);
        viewHolder.tvName.setText(item.getName());

        Bitmap bm;

        int key = item.getKey();

        if(key == 0) {
            bm = BitmapFactory.decodeResource(cxt.getResources(), R.drawable.prog_produsa);
            viewHolder.imgThumbnail.setImageBitmap(bm);
        }
        else if(key == 1) {
            bm = BitmapFactory.decodeResource(cxt.getResources(), R.drawable.prog_fromthestar);
            viewHolder.imgThumbnail.setImageBitmap(bm);
        }
        else if(key == 2){
                bm = BitmapFactory.decodeResource(cxt.getResources(), R.drawable.prog_shewasbeautiful);
                viewHolder.imgThumbnail.setImageBitmap(bm);
        }

    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        public ImageView imgThumbnail;
        public TextView tvName;

        public ViewHolder(View itemView) {
            super(itemView);
            imgThumbnail = (ImageView)itemView.findViewById(R.id.img_thumbnail);
            tvName = (TextView)itemView.findViewById(R.id.tv_name);

        }

    }

}
