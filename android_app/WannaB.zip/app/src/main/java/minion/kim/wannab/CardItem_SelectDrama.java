package minion.kim.wannab;

public class CardItem_SelectDrama {

    private String mName;
    private String mWhere;
    private int key;
    private String dbname;

    public void setDbname(String _val)
    {
        this.dbname = _val;
    }

    public String getDbname()
    {
        return dbname;
    }

    public int getKey(){
        return key;
    }

    public void setKey(int _key)
    {
        this.key = _key;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        this.mName = name;
    }

}
