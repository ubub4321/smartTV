package minion.kim.wannab;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.mikepenz.materialdrawer.*;
import com.mikepenz.materialdrawer.model.DividerDrawerItem;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.ProfileDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IProfile;


public class MainActivity extends AppCompatActivity {

    private AccountHeader headerResult = null;
    private Drawer result = null;

    private SQLiteHandler db;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        db = new SQLiteHandler((getApplicationContext()));
        session = new SessionManager(getApplicationContext());

        if(!session.isLoggedIn()){ logoutUser();}

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        PrimaryDrawerItem home = new PrimaryDrawerItem().withName("홈").withIdentifier(0).withIcon(R.drawable.home);
        PrimaryDrawerItem cart = new PrimaryDrawerItem().withName("장바구니").withIdentifier(1).withIcon(R.drawable.cart);
        PrimaryDrawerItem chkout = new PrimaryDrawerItem().withName("결제").withIdentifier(2).withIcon(R.drawable.card);
        PrimaryDrawerItem logout = new PrimaryDrawerItem().withName("로그아웃").withIdentifier(3).withIcon(R.drawable.exit);

        final IProfile profile = new ProfileDrawerItem().withName("WannaBe").withEmail("wannabe@inu.ac.kr").withIcon(R.drawable.ic_launcher).withIdentifier(100);


        setTitle("WannaBe");

        headerResult = new AccountHeaderBuilder()           // 헤더 부분
                .withActivity(this)
                .withHeaderBackground(R.drawable.header)
                .addProfiles(
                        profile
                )
                .withSavedInstance(savedInstanceState)
                .build();

        Drawer drawer = new DrawerBuilder() // drawer 빌드.
                .withActivity(this)
                .withTranslucentStatusBar(false)
                .withToolbar(toolbar)
                //.withActionBarDrawerToggle(true)
                .withSavedInstance(savedInstanceState)
                .withAccountHeader(headerResult)
                .addDrawerItems(
                        new DividerDrawerItem(),
                        home,
                        cart,
                        chkout,
                        new DividerDrawerItem(),
                        logout,
                        new DividerDrawerItem()
                )
                .withOnDrawerItemClickListener(new Drawer.OnDrawerItemClickListener() {
                    @Override
                    public boolean onItemClick(View view, int position, IDrawerItem drawerItem) {
                        //check if the drawerItem is set.
                        //there are different reasons for the drawerItem to be null
                        //--> click on the header
                        //--> click on the footer
                        //those items don't contain a drawerItem

                        if (drawerItem != null) {
                            Intent intent = null;
                            if (drawerItem.getIdentifier() == 0) {
                                selectFrag(0);
                                //intent = new Intent(MainActivity.this, WishlistFragment.class);
                            } else if (drawerItem.getIdentifier() == 1) {
                                selectFrag(1);
                                //intent = new Intent(MainActivity.this, WishlistFragment.class);
                            } else if(drawerItem.getIdentifier() == 2){
                                selectFrag(2);
                            } else if (drawerItem.getIdentifier() == 3) {
                                logoutUser();
                            }

                            if (intent != null) {
                                MainActivity.this.startActivity(intent);
                            }
                        }

                        return false;
                    }
                })

                .build();

        //getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setHomeButtonEnabled(true);

        //result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(true);

        // home fragment 로드
        Fragment fr = null;
        FragmentManager fm = getFragmentManager();

        fr = new HomeFragment();
        setTitle("드라마 선택");
        fm.beginTransaction()
                .replace(R.id.container, fr)
                .commit();
        // ---------------------

        drawer.openDrawer();
    }

    /*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {

            return true;
        }

        return super.onOptionsItemSelected(item);
    }
*/
    public void selectFrag(int view){
        Fragment fr = null;
        FragmentManager fm = getFragmentManager();

        if(view == 0){
            setTitle("WannaBe");
            fr = new HomeFragment();
        } else if(view == 1){
            setTitle("장바구니");
            fr = new WishlistFragment();
        }else if(view == 2) {
            setTitle("결제하기");
            fr = new CheckoutFragment();
        }else if(view == 3)
            logoutUser();

        fm.beginTransaction()
                .replace(R.id.container, fr)
                .commit();
    }

    private void logoutUser() {
        session.setLogin(false);

        db.deleteUsers();

        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        //handle the back press :D close the drawer first and if the drawer is closed close the activity
        if (result != null && result.isDrawerOpen()) {
            result.openDrawer();
        } else {
            super.onBackPressed();
        }
    }

}
