package minion.kim.wannab;

/**
 * Created by minion on 2015-11-19.
 */
public class LoginConfig {

    public static String URL_LOGIN = "http://meeneeon.ddns.net/android_login_api/login.php";
    public static String URL_REGISTER = "http://meeneeon.ddns.net/android_login_api/register.php";

}
