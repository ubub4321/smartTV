package minion.kim.wannab;

public class CardItem {

    private String mName;
    private String mWhere;
    private String mPrice;
    private String mWho;
    private String mImglnk;

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public String getPrice(){
        return mPrice;
    }

    public void setPrice(String price){
        this.mPrice = price;
    }

    public String getWho(){
        return mWho;
    }

    public void setWho(String who){
        this.mWho = who;
    }

    public String getWhere() {
        return mWhere;
    }

    public void setWhere(String where) {
        this.mWhere = where;
    }

    public void setLink(String link){
        this.mImglnk = link;
    }

    public String getLink(){
        return mImglnk;
    }

}
