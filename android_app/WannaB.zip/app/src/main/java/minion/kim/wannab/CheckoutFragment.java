package minion.kim.wannab;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class CheckoutFragment extends Fragment {

    String url_drop = "http://meeneeon.ddns.net/android_db_api/drop_table_cart.php?id=drop";

    ProgressDialog dialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){

        View rootView = inflater.inflate(R.layout.fragment_checkout, container, false);

        getActivity().setTitle("주문하기");

        TextView tv_total = (TextView)rootView.findViewById(R.id.tv_total);
        TextView tv_gtotal = (TextView)rootView.findViewById(R.id.tv_gtotal);

        tv_total.setText(String.valueOf(AppController.getInstance().getTotalvalue()) + " KRW");
        tv_gtotal.setText(String.valueOf(AppController.getInstance().getTotalvalue() + 2500) + " KRW");

        rootView.findViewById(R.id.btnPay).setOnClickListener(mClickListener);
        return rootView;
    }

    public void transter()
    {
        getActivity().runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(getActivity(), "주문이 성공적으로 완료되었습니다", Toast.LENGTH_LONG).show();
            }
        });

        truncateDB();

        Fragment fr = null;
        FragmentManager fm = getFragmentManager();

        fr = new HomeFragment();
        fm.beginTransaction()
                .replace(R.id.container, fr)
                .commit();
    }

    private void truncateDB()
    {
        String add_url = url_drop;
        Log.d("wannabe truncate url : ", add_url);
        JsonObjectRequest delete_request = new JsonObjectRequest(add_url,
                null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {

                try {
                    int success = response.getInt("success");

                    if (success == 1) {

                    } else {

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(delete_request);
    }

    public void timeThread() {

        dialog = new ProgressDialog(getActivity());
        dialog.setTitle("주문하기");
        dialog.setMessage("잠시만 기다려 주세요...");
        dialog.setIndeterminate(true);
        dialog.setCancelable(false);
        dialog.show();

        new Thread(new Runnable() {
            public void run() {
                // TODO Auto-generated method stub
                try {
                    Thread.sleep(500);
                } catch (Throwable ex) {
                    ex.printStackTrace();
                }
                dialog.dismiss();
                transter();

            }
        }).start();
    }

    Button.OnClickListener mClickListener = new View.OnClickListener() {
        public void onClick(View v) {
            timeThread();
        }
    };
}
