package minion.kim.wannab;

import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.ClipData;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

public class WishlistFragment extends Fragment {

    String url = "http://meeneeon.ddns.net/android_db_api/read_cart.php";
    String url_delete = "http://meeneeon.ddns.net/android_db_api/delete_cart.php?id=";

    ArrayList<CardItem>Item_List;
    ArrayList<itemtype>imglnk_list;

    ProgressDialog PD;

    private AlertDialog mDialog = null;

    public static final String NAME = "name";
    public static final String PRICE = "price";
    public static final String WHO = "who";
    public static final String WHERE = "where";
    public static final String IMGLNK = "imglnk";
    public static final String ORDLINK = "ordlnk";

    int totalitems = 0;
    int totalvalue = 0;

    RecyclerView mRecyclerView;
    RecyclerView.LayoutManager mLayoutManager;
    RecyclerView.Adapter mAdapter;

    TextView tv;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){

        totalvalue = 0;
        ReadFromDB();

        View rootView = inflater.inflate(R.layout.fragment_wishlist, container, false);
        tv = (TextView)rootView.findViewById(R.id.total);

        Item_List = new ArrayList<CardItem>();
        imglnk_list = new ArrayList<itemtype>();

        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);

        ItemClickSupport.addTo(mRecyclerView).setOnItemClickListener(new ItemClickSupport.OnItemClickListener() {
            @Override
            public void onItemClicked(RecyclerView recyclerView, int position, View v) {
                AppController.getInstance().setIdxDelete(position);

                mDialog = createInflaterDialog();
                mDialog.show();
            }
        });

        return rootView;
    }

    public class itemtype{
        public String _imglnk;
    }

    private void updatefrag()
    {
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.detach(this).attach(this).commit();
    }

    private AlertDialog createInflaterDialog() {
        final View innerView = getActivity().getLayoutInflater().inflate(R.layout.dialog_delete, null);
        AlertDialog.Builder ab = new AlertDialog.Builder(getActivity());
        ab.setTitle("항목 삭제");
        ab.setView(innerView);

        ab.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                setDelete(mDialog);
            }
        });

        ab.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                setDismiss(mDialog);
            }
        });

        return ab.create();
    }

    private void setDelete(Dialog dialog){
        if(dialog != null && dialog.isShowing()) {
            deleteDB(AppController.getInstance().getIdxDelete());
            Item_List.clear();
            //updatefrag();
            //ReadFromDB();
            dialog.dismiss();
        }
    }

    private void setDismiss(Dialog dialog){
        if(dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }

    private void updateAdapter()
    {
        Log.d("updateAdatper : ", "Called");
        mAdapter = new CardAdapter(Item_List, getActivity());
        Log.d("updateAdapter : ", "cardadapter init");
        mRecyclerView.setAdapter(mAdapter);

        gettotalvalue();
        tv.setText("  합계금액 : " + String.valueOf(AppController.getInstance().getTotalvalue()) + " KRW");
    }

    private void deleteDB(int idx)
    {
        String delete_url = url_delete + Item_List.get(idx).getLink();
        JsonObjectRequest delete_request = new JsonObjectRequest(delete_url,
                null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {

                try {
                    int success = response.getInt("success");

                    if (success == 1) {
                        Item_List.clear();
                        ReadFromDB();
                        Toast.makeText(getActivity(),
                                "장바구니에서 삭제되었습니다.",
                                Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(getActivity(),
                                "장바구니에서 삭제하는것을 실패하였습니다", Toast.LENGTH_SHORT)
                                .show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(delete_request);
    }

    void gettotalvalue()
    {
        int val = 0;
        int tmp = 0;
        String str;

        for(int i = 0; i< Item_List.size(); i++){
            str = Item_List.get(i).getPrice();
            str = str.replaceAll("\\,", "");
            val += Integer.parseInt(str);
        }
        AppController.getInstance().setTotalValue(val);
    }

    private void ReadFromDB()
    {/*
        PD = new ProgressDialog(getActivity());
        PD.setMessage("읽어들이는 중..");
        PD.setCancelable(false);

        PD.show();*/
        AppController.getInstance().setTotalValue(0);
        JsonObjectRequest req = new JsonObjectRequest(Method.GET, url, (String)null,
                new Response.Listener<JSONObject>(){

                    @Override
                    public void onResponse(JSONObject response){
                        try{
                            int success = response.getInt("success");

                            if(success == 1){
                                JSONArray ja = response.getJSONArray("cart");
                                totalitems = ja.length();

                                for (int i = 0; i < ja.length(); i++){
                                    JSONObject obj = ja.getJSONObject(i);
                                    CardItem item = new CardItem();

                                    item.setName(obj.getString(NAME));
                                    item.setPrice(obj.getString(PRICE));
                                    item.setWhere(obj.getString(WHERE));
                                    item.setWho(obj.getString(WHO));
                                    item.setLink(obj.getString(IMGLNK));

                                   // String tmpprice;
                                    Item_List.add(item);
                                   // tmpprice = obj.getString(PRICE);

                                    gettotalvalue();
                                    updateAdapter();
                                   // PD.dismiss();
                                }
                            }
                        } catch(JSONException e){
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                     @Override
                     public void onErrorResponse(VolleyError err){
                     // PD.dismiss();
                     }
        });

        AppController.getInstance().addToRequestQueue(req);
    }
}