package minion.kim.wannab;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class CardAdapter extends RecyclerView.Adapter<CardAdapter.ViewHolder> {

    List<CardItem> mItems;
    public Context cxt;

    public CardAdapter(ArrayList Items, Context _cxt) {

        super();
        this.cxt = _cxt;
        mItems = Items;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.recycler_view_card_item, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        CardItem item = mItems.get(i);
        viewHolder.tvName.setText(item.getName());
        viewHolder.tvPrice.setText(item.getPrice());
        //viewHolder.tvWho.setText(item.getWho());
        //viewHolder.tvWhere.setText(item.getWhere());

        Glide
                .with(cxt)
                .load(item.getLink())
                .asBitmap()
                .into(viewHolder.imgThumbnail);

    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        public ImageView imgThumbnail;
        public TextView tvName;
        public TextView tvPrice;
        //public TextView tvWhere;
        //public TextView tvWho;

        public ViewHolder(View itemView) {
            super(itemView);
            imgThumbnail = (ImageView)itemView.findViewById(R.id.img_thumbnail);
            tvName = (TextView)itemView.findViewById(R.id.tv_name);
            tvPrice = (TextView)itemView.findViewById(R.id.tv_price);
            //tvWhere = (TextView)itemView.findViewById(R.id.tv_where);
            //tvWho = (TextView)itemView.findViewById(R.id.tv_who);
        }

    }

}
