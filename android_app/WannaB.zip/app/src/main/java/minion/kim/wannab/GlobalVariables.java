package minion.kim.wannab;

import android.app.Application;

public class GlobalVariables extends Application {
    private int TotalValue = 0;

    public int getTotalvalue(){
        return TotalValue;
    }

    public void setTotalValue(int _value){
        this.TotalValue = _value;
    }
}
